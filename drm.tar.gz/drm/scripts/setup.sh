adduser --system --shell /bin/false --group --disabled-login drm
chown -R drm:drm /home/drm
apt-get -y install libxslt1-dev nscd htop libonig-dev libzip-dev software-properties-common aria2 psmisc libmcrypt-dev
add-apt-repository ppa:xapienz/curl34 -y
apt-get update
apt-get -y install curl libcurl4
wget -q -O /tmp/libpng12.deb http://mirrors.kernel.org/ubuntu/pool/main/libp/libpng/libpng12-0_1.2.54-1ubuntu1_amd64.deb
dpkg -i /tmp/libpng12.deb
apt-get install -y
rm /tmp/libpng12.deb
chmod +x /home/drm/bin/ffmpeg
chmod +x /home/drm/bin/mp4decrypt
chmod +x /home/drm/php/bin/php
chmod +x /home/drm/php/sbin/php-fpm
chmod +x /home/drm/nginx/sbin/nginx
ufw allow 8087
ufw allow 8088
echo "* * * * * /home/drm/php/bin/php /home/drm/includes/check.php # DRM" >> /home/drm/tmp/crontab
crontab -u drm /home/drm/tmp/crontab
service cron reload
rm /home/drm/tmp/crontab
