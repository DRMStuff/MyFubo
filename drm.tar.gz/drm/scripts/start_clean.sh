#! /bin/bash
sudo rm -r /home/drm/config/persistence.db
sudo /home/drm/scripts/start.sh