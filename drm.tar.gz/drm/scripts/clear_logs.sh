rm /home/drm/logs/error.log
rm /home/drm/logs/access.log
cd /home/drm/logs/build/ && find . -name "*.log" -print0 | xargs -0 rm
cd /home/drm/logs/ffmpeg/ && find . -name "*.log" -print0 | xargs -0 rm
rm /home/drm/logs/*.log
rm /home/drm/tmp/*.txt
rm /home/drm/php/var/log/php-fpm.log