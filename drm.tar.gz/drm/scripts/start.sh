#! /bin/bash
sudo killall -9 -u drm nginx
sudo killall -9 -u drm php-fpm
sleep 1
sudo killall -9 -u drm nginx
sudo killall -9 -u drm php-fpm
sleep 1
sudo -u drm /home/drm/nginx/sbin/nginx
sudo -u drm start-stop-daemon --start --quiet --pidfile /home/drm/php/daemon.pid --exec /home/drm/php/sbin/php-fpm -- --daemonize --fpm-config /home/drm/php/etc/daemon.conf
sudo -u drm /home/drm/php/bin/php /home/drm/includes/check.php 1
