#! /bin/bash
sudo killall -9 -u drm nginx
sudo killall -9 -u drm php-fpm
sudo killall -9 -u drm ffmpeg
sudo killall -9 -u drm php
sudo rm -rf /home/drm/video/*
sudo rm -rf /home/drm/hls/*
sudo rm -f /home/drm/cache/*.db
sudo rm -f /home/drm/php/daemon.sock